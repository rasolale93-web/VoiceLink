package com.voicelink.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

/** VoiceLink v0.8 control panel. Call engine runs in CallService. */
public class MainActivity extends Activity {
    LinearLayout root; TextView status; EditText server, room, token;
    SharedPreferences prefs;
    boolean autoAnswer;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("voicelink", MODE_PRIVATE);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,32,28,28);
        TextView title = new TextView(this); title.setText("VoiceLink v0.8\nتماس صوتی"); title.setTextSize(26); title.setGravity(Gravity.CENTER); root.addView(title);
        server = field("آدرس WebSocket سرور", prefs.getString("server", ""));
        room = field("کد اتصال", prefs.getString("room", ""));
        token = field("رمز اتصال", prefs.getString("token", ""));
        root.addView(server); root.addView(room); root.addView(token);

        Button parent = new Button(this); parent.setText("حالت تماس‌گیرنده"); parent.setOnClickListener(v -> startRole("PARENT")); root.addView(parent);
        Button child = new Button(this); child.setText("حالت گیرنده"); child.setOnClickListener(v -> startRole("CHILD")); root.addView(child);
        Button hang = new Button(this); hang.setText("قطع تماس / توقف سرویس"); hang.setOnClickListener(v -> stopCallService()); root.addView(hang);

        autoAnswer = prefs.getBoolean("auto_answer", false);
        Switch ready = new Switch(this); ready.setText("آماده دریافت خودکار در پس‌زمینه"); ready.setChecked(autoAnswer);
        ready.setOnCheckedChangeListener((v, checked) -> {
            autoAnswer = checked; save(); prefs.edit().putBoolean("auto_answer", checked).apply();
            if (checked) startRole("CHILD"); else stopCallService();
            show(checked ? "حالت آماده دریافت فعال شد" : "حالت آماده دریافت خاموش شد");
        });
        root.addView(ready);

        Button saveButton = new Button(this);
        saveButton.setText("ذخیره تنظیمات");
        saveButton.setOnClickListener(v -> { save(); show("تنظیمات ذخیره شد"); });
        root.addView(saveButton);

        Button mic = new Button(this); mic.setText("بررسی مجوز میکروفون"); mic.setOnClickListener(v -> requestMic()); root.addView(mic);
        status = new TextView(this); status.setText("\nوضعیت: آماده"); status.setTextColor(Color.DKGRAY); root.addView(status);
        setContentView(root);

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) status.setText("\nمجوز میکروفون لازم است");
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value); e.setSingleLine(true); return e;
    }

    private void save() {
        prefs.edit().putString("server", server.getText().toString().trim())
            .putString("room", room.getText().toString().trim())
            .putString("token", token.getText().toString().trim()).apply();
    }

    private void startRole(String role) {
        save();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestMic(); return; }
        prefs.edit().putString("role", role).apply();
        Intent i = new Intent(this, CallService.class).putExtra(CallService.EXTRA_ROLE, role);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        show("سرویس تماس برای " + ("CHILD".equals(role) ? "گیرنده" : "تماس‌گیرنده") + " فعال شد");
    }

    private void stopCallService() { stopService(new Intent(this, CallService.class)); show("سرویس متوقف شد"); }

    private void requestMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100);
        else show("مجوز میکروفون فعال است");
    }

    private void show(String s) { if (status != null) status.setText("\n" + s); }

    @Override protected void onDestroy() { save(); super.onDestroy(); }
}
