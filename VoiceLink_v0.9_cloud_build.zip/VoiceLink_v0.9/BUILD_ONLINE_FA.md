# ساخت APK بدون نصب Android Studio روی کامپیوتر شخصی

این پروژه برای GitHub Actions یک workflow دارد.

1. پروژه را در یک repository شخصی GitHub قرار دهید.
2. شاخه `main` را ایجاد کنید.
3. به بخش Actions بروید.
4. workflow با نام `VoiceLink Android Build` را اجرا کنید.
5. پس از موفقیت، artifact با نام `VoiceLink-v0.9-debug-apk` قابل دریافت است.

این APK نسخه آزمایشی (debug) است و برای تست روی گوشی مناسب است؛ برای انتشار نهایی باید نسخه release با کلید امضای اختصاصی ساخته شود.
