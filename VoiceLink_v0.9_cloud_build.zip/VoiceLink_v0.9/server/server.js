const WebSocket = require('ws');
const crypto = require('crypto');
const PORT = Number(process.env.PORT || 8080);
const rooms = new Map();
const TURN_URL = process.env.TURN_URL || '';
const TURN_USERNAME = process.env.TURN_USERNAME || '';
const TURN_PASSWORD = process.env.TURN_PASSWORD || '';

function validRoom(s){ return typeof s === 'string' && /^[A-Za-z0-9_-]{6,64}$/.test(s); }
function validToken(s){ return typeof s === 'string' && s.length >= 12 && s.length <= 128; }
function send(ws, obj){ if(ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }

const wss = new WebSocket.Server({ port: PORT });
wss.on('connection', ws => {
  ws.id = crypto.randomUUID();
  ws.on('message', raw => {
    let m; try { m=JSON.parse(raw.toString()); } catch { return send(ws,{type:'error',message:'invalid_json'}); }
    if(m.type==='join'){
      if(!validRoom(m.room) || !validToken(m.token)) return send(ws,{type:'error',message:'invalid_credentials'});
      let r=rooms.get(m.room);
      if(!r){ r={token:m.token, peers:new Set()}; rooms.set(m.room,r); }
      if(r.token!==m.token || r.peers.size>=2) return send(ws,{type:'error',message:'room_denied'});
      r.peers.add(ws); ws.room=m.room; send(ws,{type:'joined',peerCount:r.peers.size});
      if (TURN_URL && TURN_USERNAME && TURN_PASSWORD) send(ws,{type:'turn_config',urls:[TURN_URL],username:TURN_USERNAME,password:TURN_PASSWORD});
      for(const p of r.peers) if(p!==ws) send(p,{type:'peer_joined'});
      return;
    }
    if(!ws.room) return send(ws,{type:'error',message:'not_joined'});
    const r=rooms.get(ws.room); if(!r) return;
    if(['offer','answer','ice','hangup'].includes(m.type)) {
      const allowed = m.type==='hangup' || (m.type==='offer'||m.type==='answer') && typeof m.sdp==='string' && m.sdp.length<200000 || m.type==='ice' && m.candidate && typeof m.candidate.candidate==='string' && m.candidate.candidate.length<10000;
      if(!allowed) return send(ws,{type:'error',message:'invalid_signal'});
      for(const p of r.peers) if(p!==ws) send(p,{...m,from:ws.id});
    }
  });
  ws.on('close',()=>{
    if(!ws.room) return; const r=rooms.get(ws.room); if(!r) return; r.peers.delete(ws);
    for(const p of r.peers) send(p,{type:'peer_left'}); if(r.peers.size===0) rooms.delete(ws.room);
  });
});
console.log(`VoiceLink signaling server listening on ${PORT}`);
