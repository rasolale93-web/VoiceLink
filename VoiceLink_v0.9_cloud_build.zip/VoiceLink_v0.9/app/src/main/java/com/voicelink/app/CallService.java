package com.voicelink.app;

import android.app.*;
import android.content.*;
import android.media.AudioManager;
import android.os.*;
import android.text.TextUtils;
import org.json.*;
import org.webrtc.*;
import okhttp3.*;
import java.util.*;

/**
 * VoiceLink v0.8 background call engine with signaling/WebRTC fixes.
 * The user explicitly enables Ready mode on the child device.
 * WebSocket + WebRTC now live in the foreground service rather than Activity.
 */
public class CallService extends Service {
    public static final String ACTION_START = "com.voicelink.app.START";
    public static final String ACTION_HANGUP = "com.voicelink.app.HANGUP";
    public static final String EXTRA_ROLE = "role";
    public static final String CHANNEL = "voicelink_calls";
    public static final int NOTIFY_ID = 1201;

    private SharedPreferences prefs;
    private OkHttpClient http;
    private WebSocket socket;
    private PeerConnectionFactory factory;
    private PeerConnection peer;
    private AudioSource audioSource;
    private AudioTrack localAudio;
    private boolean remoteDescriptionSet = false;
    private boolean stopping = false;
    private boolean reconnectScheduled = false;
    private String role = "";
    private final Queue<IceCandidate> pendingIce = new ArrayDeque<>();
    private final List<PeerConnection.IceServer> configuredIce = new ArrayList<>();

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("voicelink", MODE_PRIVATE);
        createChannel();
        startForeground(NOTIFY_ID, notification("در حال آماده‌سازی تماس"));
        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        if (am != null) am.setMode(AudioManager.MODE_IN_COMMUNICATION);
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions());
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory();
        prepareAudio();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_HANGUP.equals(intent.getAction())) {
            hangup();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && intent.hasExtra(EXTRA_ROLE)) {
            role = intent.getStringExtra(EXTRA_ROLE);
            if (role == null) role = "";
            prefs.edit().putString("role", role).apply();
        } else {
            role = prefs.getString("role", "");
        }
        if ("PARENT".equals(role) || "CHILD".equals(role)) connect();
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "VoiceLink calls", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("VoiceLink تماس صوتی");
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, flags);
        Intent stop = new Intent(this, CallService.class).setAction(ACTION_HANGUP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.sym_call_incoming)
         .setContentTitle("VoiceLink")
         .setContentText(text)
         .setContentIntent(pi)
         .setOngoing(true)
         .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "قطع", stopPi).build());
        return b.build();
    }

    private void status(String s) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFY_ID, notification(s));
        Intent i = new Intent("com.voicelink.app.STATUS");
        i.putExtra("text", s);
        sendBroadcast(i);
    }

    private void prepareAudio() {
        if (factory == null || audioSource != null) return;
        audioSource = factory.createAudioSource(new MediaConstraints());
        localAudio = factory.createAudioTrack("VL_AUDIO", audioSource);
        localAudio.setEnabled(true);
    }

    private void connect() {
        if (socket != null) return;
        String url = prefs.getString("server", "").trim();
        if (TextUtils.isEmpty(url)) { status("آدرس سرور تنظیم نشده است"); return; }
        http = new OkHttpClient();
        Request req = new Request.Builder().url(url).build();
        status("در حال اتصال به سرور...");
        socket = http.newWebSocket(req, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response r) { reconnectScheduled = false; socket = ws; sendJoin(); }
            @Override public void onMessage(WebSocket ws, String text) { handleSignal(text); }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) {
                socket = null;
                status("خطای اتصال؛ تلاش مجدد...");
                scheduleReconnect();
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                socket = null;
                if (!stopping) { status("ارتباط قطع شد؛ تلاش مجدد..."); scheduleReconnect(); }
            }
        });
    }

    private void scheduleReconnect() {
        if (stopping || reconnectScheduled) return;
        reconnectScheduled = true;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                reconnectScheduled = false;
                if (!stopping && socket == null) connect();
            }
        }, 3000);
    }

    private void sendJoin() {
        try {
            JSONObject o = new JSONObject();
            o.put("type", "join");
            o.put("room", prefs.getString("room", "").trim());
            o.put("token", prefs.getString("token", "").trim());
            socket.send(o.toString());
        } catch (Exception e) { status("خطا در ورود به اتاق"); }
    }

    private void handleSignal(String text) {
        try {
            JSONObject m = new JSONObject(text);
            String type = m.optString("type");
            if (type.equals("joined")) {
                status("متصل و آماده دریافت تماس");
            } else if (type.equals("peer_joined")) {
                status("دستگاه مقابل متصل شد");
                createPeer();
                if ("PARENT".equals(role)) makeOffer();
            } else if (type.equals("offer")) {
                createPeer();
                final boolean shouldAnswer = "CHILD".equals(role) && prefs.getBoolean("auto_answer", false);
                setRemote(m.getString("sdp"), new Runnable() {
                    @Override public void run() {
                        if (shouldAnswer) {
                            makeAnswer();
                            status("تماس دریافت شد؛ پاسخ خودکار فعال است");
                        } else if ("CHILD".equals(role)) {
                            status("تماس ورودی؛ پاسخ خودکار خاموش است");
                        }
                    }
                });
            } else if (type.equals("answer")) {
                setRemote(m.getString("sdp"), null);
            } else if (type.equals("turn_config")) {
                configuredIce.clear();
                JSONArray urls = m.optJSONArray("urls");
                if (urls != null && urls.length() > 0) {
                    PeerConnection.IceServer.Builder b = PeerConnection.IceServer.builder(urls.getString(0));
                    b.setUsername(m.optString("username"));
                    b.setPassword(m.optString("password"));
                    configuredIce.add(b.createIceServer());
                }
            } else if (type.equals("ice")) {
                JSONObject c = m.getJSONObject("candidate");
                IceCandidate ic = new IceCandidate(c.getString("sdpMid"), c.getInt("sdpMLineIndex"), c.getString("candidate"));
                if (peer != null && remoteDescriptionSet) peer.addIceCandidate(ic); else pendingIce.add(ic);
            } else if (type.equals("hangup") || type.equals("peer_left")) {
                closePeer();
                status(type.equals("peer_left") ? "دستگاه مقابل از اتصال خارج شد" : "تماس توسط دستگاه مقابل قطع شد");
            } else if (type.equals("error")) {
                status("خطا: " + m.optString("message"));
            }
        } catch (Exception e) { status("پیام نامعتبر از سرور"); }
    }

    private void createPeer() {
        if (peer != null) return;
        List<PeerConnection.IceServer> ice = new ArrayList<>();
        ice.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer());
        ice.addAll(configuredIce);
        PeerConnection.RTCConfiguration cfg = new PeerConnection.RTCConfiguration(ice);
        peer = factory.createPeerConnection(cfg, new PeerConnection.Observer() {
            public void onSignalingChange(PeerConnection.SignalingState s) {}
            public void onIceConnectionChange(PeerConnection.IceConnectionState s) { status("اتصال صدا: " + s.name()); }
            public void onIceConnectionReceivingChange(boolean b) {}
            public void onIceGatheringChange(PeerConnection.IceGatheringState s) {}
            public void onIceCandidate(IceCandidate c) {
                try {
                    JSONObject x = new JSONObject(); x.put("type", "ice");
                    JSONObject q = new JSONObject(); q.put("candidate", c.sdp); q.put("sdpMid", c.sdpMid); q.put("sdpMLineIndex", c.sdpMLineIndex);
                    x.put("candidate", q); if (socket != null) socket.send(x.toString());
                } catch (Exception ignored) {}
            }
            public void onIceCandidatesRemoved(IceCandidate[] c) {}
            public void onAddStream(MediaStream s) {}
            public void onRemoveStream(MediaStream s) {}
            public void onDataChannel(DataChannel d) {}
            public void onRenegotiationNeeded() {}
            public void onAddTrack(RtpReceiver r, MediaStream[] ms) { if (r.track() instanceof AudioTrack) ((AudioTrack)r.track()).setEnabled(true); }
        });
        if (peer != null && localAudio != null) peer.addTrack(localAudio);
    }

    private void makeOffer() {
        if (peer == null) return;
        peer.createOffer(new SimpleSdp() {
            public void onCreateSuccess(SessionDescription d) {
                if (peer != null) peer.setLocalDescription(new SimpleSdp(), d);
                sendSdp("offer", d);
            }
            public void onCreateFailure(String e) { status("خطا در ساخت تماس: " + e); }
        }, new MediaConstraints());
    }

    private void makeAnswer() {
        if (peer == null) return;
        peer.createAnswer(new SimpleSdp() {
            public void onCreateSuccess(SessionDescription d) {
                if (peer != null) peer.setLocalDescription(new SimpleSdp(), d);
                sendSdp("answer", d);
            }
            public void onCreateFailure(String e) { status("خطا در پاسخ تماس: " + e); }
        }, new MediaConstraints());
    }

    private void setRemote(String sdp, final Runnable afterSuccess) {
        if (peer == null) return;
        SessionDescription.Type type = "PARENT".equals(role) ? SessionDescription.Type.ANSWER : SessionDescription.Type.OFFER;
        peer.setRemoteDescription(new SimpleSdp() {
            public void onSetSuccess() {
                remoteDescriptionSet = true;
                while (!pendingIce.isEmpty() && peer != null) peer.addIceCandidate(pendingIce.poll());
                if (afterSuccess != null) afterSuccess.run();
            }
            public void onSetFailure(String error) { status("خطا در تنظیم ارتباط صدا: " + error); }
        }, new SessionDescription(type, sdp));
    }

    private void sendSdp(String type, SessionDescription d) {
        try { if (socket == null) return; JSONObject x = new JSONObject(); x.put("type", type); x.put("sdp", d.description); socket.send(x.toString()); }
        catch (Exception ignored) {}
    }

    private void hangup() {
        try { if (socket != null) { JSONObject x = new JSONObject(); x.put("type", "hangup"); socket.send(x.toString()); } } catch (Exception ignored) {}
        closePeer();
    }

    private void closePeer() {
        remoteDescriptionSet = false;
        pendingIce.clear();
        if (peer != null) { peer.close(); peer = null; }
    }

    static class SimpleSdp implements SdpObserver {
        public void onCreateSuccess(SessionDescription d) {} public void onSetSuccess() {}
        public void onCreateFailure(String s) {} public void onSetFailure(String s) {}
    }

    @Override public void onDestroy() {
        stopping = true;
        hangup();
        if (socket != null) { socket.close(1000, "service stopped"); socket = null; }
        if (audioSource != null) { audioSource.dispose(); audioSource = null; }
        if (factory != null) { factory.dispose(); factory = null; }
        if (http != null) { http.dispatcher().executorService().shutdown(); http = null; }
        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        if (am != null) am.setMode(AudioManager.MODE_NORMAL);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
